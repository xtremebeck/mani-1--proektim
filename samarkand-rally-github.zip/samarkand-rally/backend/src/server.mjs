import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import { JsonStore } from "./store.mjs";
import { buildProgress, claimReward, claimStamp } from "./domain.mjs";
import { publicRally, RALLY } from "./rally-data.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const store = new JsonStore(path.join(root, "data", "store.json"));
const port = Number.parseInt(process.env.PORT ?? "4173", 10);
const adminKey = process.env.ADMIN_KEY ?? "rally-dev-admin-key";
const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".png": "image/png" };
await store.initialize();

function send(res, status, body, id) { const payload = JSON.stringify(body); res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(payload), "Cache-Control": "no-store", "X-Request-Id": id }); res.end(payload); }
function fail(res, status, code, message, id) { send(res, status, { error: { code, message }, requestId: id }, id); }
async function body(req) { const chunks = []; let size = 0; for await (const c of req) { size += c.length; if (size > 32768) throw Error("REQUEST_TOO_LARGE"); chunks.push(c); } try { return size ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}; } catch { throw Error("INVALID_JSON"); } }
async function auth(req, res, id) { const h = req.headers.authorization; const token = typeof h === "string" && h.startsWith("Bearer ") ? h.slice(7) : null; if (!token) { fail(res, 401, "AUTH_REQUIRED", "Session token kerak.", id); return null; } const session = await store.getSession(token); if (!session) { fail(res, 401, "INVALID_SESSION", "Session topilmadi.", id); return null; } return { token, session }; }
async function staticFile(req, res, id) { const pathname = new URL(req.url, "http://localhost").pathname; const target = pathname === "/" ? "/index.html" : pathname; const file = path.resolve(root, `.${decodeURIComponent(target)}`); if (!file.startsWith(root + path.sep)) return fail(res, 403, "FORBIDDEN", "Ruxsat yo'q.", id); try { if (!(await stat(file)).isFile()) throw Error(); const content = await readFile(file); res.writeHead(200, { "Content-Type": mime[path.extname(file)] ?? "application/octet-stream", "Content-Length": content.length, "X-Request-Id": id }); res.end(content); } catch { fail(res, 404, "NOT_FOUND", "Sahifa topilmadi.", id); } }

const server = createServer(async (req, res) => {
  const id = randomUUID();
  try {
    const pathname = new URL(req.url, "http://localhost").pathname;
    if (req.method === "GET" && pathname === "/api/v1/health") return send(res, 200, { status: "ok", service: "samarkand-rally-api" }, id);
    if (req.method === "GET" && pathname === "/api/v1/rallies/samarkand-secrets") return send(res, 200, { rally: publicRally() }, id);
    if (req.method === "POST" && pathname === "/api/v1/sessions") { const input = await body(req); const session = await store.createSession({ language: ["UZ", "EN", "RU"].includes(input.language) ? input.language : "UZ" }); return send(res, 201, { session }, id); }
    if (req.method === "GET" && pathname === "/api/v1/me/progress") { const a = await auth(req, res, id); if (!a) return; return send(res, 200, { progress: buildProgress(a.session.progress) }, id); }
    if (req.method === "POST" && pathname === "/api/v1/stamps/claim") { const a = await auth(req, res, id); if (!a) return; const result = claimStamp(a.session.progress, await body(req)); if (!result.ok) return fail(res, result.status, result.error, result.message, id); if (!result.duplicate) await store.updateProgress(a.token, result.nextProgress); return send(res, 200, { progress: result.progress, duplicate: result.duplicate }, id); }
    if (req.method === "POST" && pathname === "/api/v1/rewards/claim") { const a = await auth(req, res, id); if (!a) return; const result = claimReward(a.session.progress); if (!result.ok) return fail(res, result.status, result.error, result.message, id); await store.updateProgress(a.token, result.nextProgress); return send(res, 200, { progress: result.progress }, id); }
    if (req.method === "POST" && pathname === "/api/v1/guide/chat") {
      const a = await auth(req, res, id); if (!a) return;
      const input = await body(req); const message = typeof input.message === "string" ? input.message.trim() : "";
      if (!message || message.length > 300) return fail(res, 400, "INVALID_MESSAGE", "Savol 1-300 belgi bo'lishi kerak.", id);
      const stop = RALLY.stops.find((item) => item.id === input.stopId) ?? RALLY.stops.find((item) => item.id === buildProgress(a.session.progress).nextStopId);
      const language = a.session.language;
      const russianNames = { registan: "Регистан", bibixonim: "Мечеть Биби-Ханым", siyob: "Сиабский базар", "shohi-zinda": "Шахи-Зинда", konigil: "Конигил", ulugbek: "Обсерватория Улугбека" };
      const reply = language === "RU"
        ? `${russianNames[stop?.id] ?? "Самарканд"}: начните с истории этого места и возьмите штамп после осмотра. Следующий активный штамп: ${russianNames[buildProgress(a.session.progress).nextStopId] ?? "все точки пройдены"}.`
        : language === "EN"
          ? `${stop?.name ?? "Samarkand"}: ${stop?.story ?? "I can help you choose your next step."} Your next active stamp is ${RALLY.stops.find((item) => item.id === buildProgress(a.session.progress).nextStopId)?.name ?? "the rally is complete"}.`
          : `${stop?.name ?? "Samarqand"}: ${stop?.story ?? "Keyingi qadamingizni tanlashga yordam beraman."} Keyingi faol stamp: ${RALLY.stops.find((item) => item.id === buildProgress(a.session.progress).nextStopId)?.name ?? "barcha nuqta tugallangan"}.`;
      return send(res, 200, { reply, contextStopId: stop?.id ?? null }, id);
    }
    if (req.method === "GET" && pathname === "/api/v1/admin/overview") {
      if (req.headers["x-admin-key"] !== adminKey) return fail(res, 401, "ADMIN_REQUIRED", "Admin kaliti noto'g'ri.", id);
      const sessions = Object.values((await store.snapshot()).sessions);
      const completed = sessions.filter((s) => s.progress.claimedStopIds.length === 6);
      const claims = sessions.reduce((sum, s) => sum + s.progress.claimedStopIds.length, 0);
      const languages = sessions.reduce((acc, s) => ({ ...acc, [s.language]: (acc[s.language] ?? 0) + 1 }), {});
      return send(res, 200, { metrics: { sessions: sessions.length, claims, completed: completed.length, completionRate: sessions.length ? Math.round(completed.length / sessions.length * 100) : 0 }, languages, recent: sessions.sort((a, b) => b.lastSeenAt.localeCompare(a.lastSeenAt)).slice(0, 12).map((s) => ({ id: s.id.slice(0, 8), language: s.language, stamps: s.progress.claimedStopIds.length, completed: s.progress.claimedStopIds.length === 6 })) }, id);
    }
    return staticFile(req, res, id);
  } catch (e) { if (e.message === "INVALID_JSON" || e.message === "REQUEST_TOO_LARGE") return fail(res, 400, e.message, "So'rov formati noto'g'ri.", id); console.error(`[${id}]`, e); return fail(res, 500, "INTERNAL_ERROR", "Kutilmagan xatolik yuz berdi.", id); }
});
server.listen(port, "127.0.0.1", () => console.log(`Samarqand Rally: http://127.0.0.1:${port}`));
