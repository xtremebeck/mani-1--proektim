let stops = [];
let lang = localStorage.getItem("rally-lang") || "UZ";
let token = localStorage.getItem("samarkand-rally-session");
let progress = { claimedStopIds: [], claimedCount: 0, totalStops: 6, completed: false, nextStopId: "registan" };
let activeStop = null;
let scannerStream = null;
let scannerTimer = null;
const demoStops = [
  { id: "registan", name: "Registon", hint: "Uch madrasa orasidagi sirli nisbatni toping.", story: "Registon bir vaqtlar shaharning yuragi edi.", point: [18, 220], stampCode: "SAM-REG-2026" },
  { id: "bibixonim", name: "Bibixonim masjidi", hint: "Ulkan peshtoq ostidagi ko'k naqshni toping.", story: "Bu masjid Samarqandning kuchi va buyuk orzusini eslatadi.", point: [112, 161], stampCode: "SAM-BIB-2026" },
  { id: "siyob", name: "Siyob bozori", hint: "Mahalliy nonning hidini toping.", story: "Siyob bozori sayohatni ta'm va insoniy suhbat bilan to'ldiradi.", point: [204, 190], stampCode: "SAM-SIY-2026" },
  { id: "shohi-zinda", name: "Shohi Zinda", hint: "Ko'k rangning uch xil tusini sanang.", story: "Shohi Zinda yo'lagi asrlar davomida saqlangan ranglar muzeyi.", point: [277, 105], stampCode: "SAM-SHZ-2026", aliases: ["SAM-SHO-2026", "SAM-SHOHI-2026"] },
  { id: "konigil", name: "Konigil qog'oz ustaxonasi", hint: "Qog'oz qanday tug'ilishini ko'ring.", story: "Bu yerda qadimiy qog'oz tayyorlash usuli hali ham tirik.", point: [348, 174], stampCode: "SAM-KON-2026" },
  { id: "ulugbek", name: "Ulug'bek rasadxonasi", hint: "Yulduzlar uchun qurilgan belgi yonida turing.", story: "Ulug'bek osmonni kuzatib, ilm uchun yangi yo'l ochgan.", point: [402, 68], stampCode: "SAM-ULU-2026" }
];
const demoMode = !["127.0.0.1", "localhost"].includes(location.hostname);

const texts = {
  UZ: { today: "BUGUNGI SARGUZASHT", heroTitle: "Samarqand sirlari", heroText: "Qadimiy shaharni oddiy turist emas, kashfiyotchi sifatida ko'ring.", start: "Missiyani boshlash", passport: "SIZNING PASPORTINGIZ", stamps: "stamp", passportCaption: "Har bir nuqta yangi hikoya ochadi", routeLabel: "BUGUNGI YO'L", routeTitle: "6 nuqta. Bitta hikoya.", duration: "2 soat 20 daqiqa", discover: "Kashfiyot", map: "Xarita", passportNav: "Pasport", guideNav: "Guide", rewards: "Mukofot", mapLabel: "SIZNING YO'LINGIZ", mapTitle: "Shahar ichidagi izlar", mapCaption: "Har bir belgi faqat joyga yetganingizdan keyin ochiladi.", passportTitle: "Samarqand sirlari", passportText: "Har stamp bu shahar bilan bo'lgan haqiqiy uchrashuv.", reset: "Rallyni yangidan boshlash", stampReady: "STAMP TAYYOR", collect: "Stampni olish", rewardTitle: "Medal sizni kutmoqda", rewardLocked: "Barcha 6 stampni to'plang. Yakunda sizni cheklangan Samarqand medali va postcard kutadi.", rewardUnlocked: "Samarqand kashfiyotchisi", rewardDone: "Siz barcha nuqtani bosib o'tdingiz. Hamkor nuqtada medal va postcard'ingizni olib keting.", guideLabel: "SIZNING GUIDE'INGIZ", guideTitle: "Sayohat ichidagi hamroh", guideIntro: "Joy tarixi, keyingi qadam yoki qisqa tavsiya haqida so'rang.", guideWelcome: "Men Samarqand rally guide'iman. Qayerga borishni bilmasangiz, so'rang.", guideNext: "Keyingi joy qayerda?", guideStory: "Bu joyning hikoyasi nima?", guidePlaceholder: "Savolingizni yozing", next: "KEYINGI MISSIYA", collected: "STAMP OLINGAN", locked: "YOPIQ NUQTA", lockedStamp: "Yopiq stamp", unlock: "Keyingi nuqtani oching" },
  EN: { today: "TODAY'S ADVENTURE", heroTitle: "Secrets of Samarkand", heroText: "See the ancient city as an explorer, not an ordinary tourist.", start: "Start the mission", passport: "YOUR PASSPORT", stamps: "stamps", passportCaption: "Every stop reveals another story", routeLabel: "TODAY'S PATH", routeTitle: "6 stops. One story.", duration: "2 hours 20 minutes", discover: "Discover", map: "Map", passportNav: "Passport", guideNav: "Guide", rewards: "Reward", mapLabel: "YOUR PATH", mapTitle: "Traces through the city", mapCaption: "Each marker unlocks only when you reach the place.", passportTitle: "Secrets of Samarkand", passportText: "Every stamp is a real encounter with the city.", reset: "Restart the rally", stampReady: "STAMP READY", collect: "Collect stamp", rewardTitle: "The medal is waiting", rewardLocked: "Collect all 6 stamps. A limited Samarkand medal and postcard await at the finish.", rewardUnlocked: "Samarkand explorer", rewardDone: "You have completed every stop. Claim your medal and postcard at the partner point.", guideLabel: "YOUR GUIDE", guideTitle: "Your companion inside the journey", guideIntro: "Ask for a story, a next step, or a quick local suggestion.", guideWelcome: "I am your Samarkand Rally guide. Ask me whenever you need a direction.", guideNext: "Where is my next stop?", guideStory: "What is this place's story?", guidePlaceholder: "Write your question", next: "NEXT MISSION", collected: "STAMP COLLECTED", locked: "LOCKED STOP", lockedStamp: "Locked stamp", unlock: "Unlock the next stop" },
  RU: { today: "ПРИКЛЮЧЕНИЕ СЕГОДНЯ", heroTitle: "Тайны Самарканда", heroText: "Откройте древний город как исследователь, а не как обычный турист.", start: "Начать миссию", passport: "ВАШ ПАСПОРТ", stamps: "штампов", passportCaption: "Каждая точка открывает новую историю", routeLabel: "ПУТЬ НА СЕГОДНЯ", routeTitle: "6 точек. Одна история.", duration: "2 часа 20 минут", discover: "Открытия", map: "Карта", passportNav: "Паспорт", guideNav: "Гид", rewards: "Награда", mapLabel: "ВАШ ПУТЬ", mapTitle: "Следы в городе", mapCaption: "Каждая отметка открывается только когда вы окажетесь на месте.", passportTitle: "Тайны Самарканда", passportText: "Каждый штамп - это настоящая встреча с городом.", reset: "Начать заново", stampReady: "ШТАМП ГОТОВ", collect: "Получить штамп", rewardTitle: "Медаль ждёт вас", rewardLocked: "Соберите все 6 штампов. В конце вас ждут медаль и открытка Самарканда.", rewardUnlocked: "Исследователь Самарканда", rewardDone: "Вы прошли все точки. Заберите медаль и открытку у партнера.", guideLabel: "ВАШ ГИД", guideTitle: "Ваш спутник в путешествии", guideIntro: "Спросите об истории места, следующем шаге или местном совете.", guideWelcome: "Я ваш гид Samarkand Rally. Спросите меня, если понадобится направление.", guideNext: "Где следующая точка?", guideStory: "Какая история у этого места?", guidePlaceholder: "Напишите свой вопрос", next: "СЛЕДУЮЩАЯ МИССИЯ", collected: "ШТАМП ПОЛУЧЕН", locked: "ТОЧКА ЗАКРЫТА", lockedStamp: "Закрытый штамп", unlock: "Откройте следующую точку" }
};

const $ = (selector) => document.querySelector(selector);
const all = (selector) => [...document.querySelectorAll(selector)];
const t = (key) => texts[lang][key];
const done = (id) => progress.claimedStopIds.includes(id);
const localizedStops = {
  EN: { registan: ["Registan", "Find the hidden symmetry between three madrasas.", "Registan was once the heart of the city, where merchants, scholars, and travellers met."], bibixonim: ["Bibi-Khanym Mosque", "Find the blue pattern beneath the monumental portal.", "This mosque recalls Samarkand's strength and great ambition."], siyob: ["Siab Bazaar", "Follow the scent of local bread.", "Siab Bazaar fills the journey with flavour and conversation."], "shohi-zinda": ["Shah-i-Zinda", "Count three shades of blue.", "The Shah-i-Zinda passage is a museum of colour kept for centuries."], konigil: ["Konigil Paper Workshop", "See how paper comes to life.", "The ancient method of making paper is still alive here."], ulugbek: ["Ulugh Beg Observatory", "Stand beside the monument built for the stars.", "Ulugh Beg observed the sky and opened a new path for science."] },
  RU: { registan: ["Регистан", "Найдите скрытую симметрию между тремя медресе.", "Регистан когда-то был сердцем города, где встречались купцы, учёные и путешественники."], bibixonim: ["Мечеть Биби-Ханым", "Найдите голубой узор под монументальным порталом.", "Эта мечеть напоминает о силе и великой мечте Самарканда."], siyob: ["Сиабский базар", "Следуйте за ароматом местного хлеба.", "Сиабский базар наполняет путешествие вкусом и разговорами."], "shohi-zinda": ["Шахи-Зинда", "Сосчитайте три оттенка синего.", "Коридор Шахи-Зинда - музей цвета, сохранённый на века."], konigil: ["Бумажная мастерская Конигил", "Посмотрите, как рождается бумага.", "Здесь до сих пор жив древний способ изготовления бумаги."], ulugbek: ["Обсерватория Улугбека", "Встаньте у знака, построенного для звёзд.", "Улугбек наблюдал за небом и открыл новый путь для науки."] }
};
function copyFor(stop) { const copy = localizedStops[lang]?.[stop.id]; return copy ? { name: copy[0], hint: copy[1], story: copy[2] } : stop; }

async function api(path, options = {}) {
  if (demoMode) return localDemoApi(path, options);
  const response = await fetch(`/api/v1${path}`, { ...options, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers } });
  const data = await response.json();
  if (!response.ok) throw Error(data.error?.message || "Server bilan bog'lanib bo'lmadi.");
  return data;
}

function demoProgress() {
  const saved = JSON.parse(localStorage.getItem("samarkand-rally-demo-progress") || "[]");
  const claimedStopIds = Array.isArray(saved) ? saved : [];
  return { claimedStopIds, claimedCount: claimedStopIds.length, totalStops: demoStops.length, completed: claimedStopIds.length === demoStops.length, nextStopId: demoStops.find((stop) => !claimedStopIds.includes(stop.id))?.id ?? null };
}

async function localDemoApi(path, options) {
  if (path === "/rallies/samarkand-secrets") return { rally: { stops: demoStops.map(({ stampCode, aliases, ...stop }) => stop) } };
  if (path === "/sessions") return { session: { token: "public-demo" } };
  if (path === "/me/progress") return { progress: demoProgress() };
  if (path === "/stamps/claim") {
    const input = JSON.parse(options.body || "{}"); const current = demoProgress(); const stop = demoStops.find((item) => item.id === input.stopId);
    if (!stop || current.nextStopId !== input.stopId) throw Error("Avval oldingi nuqtadagi stampni oling.");
    const accepted = [stop.stampCode, ...(stop.aliases || [])];
    if (!accepted.includes(String(input.stampCode || "").trim().toUpperCase())) throw Error("QR stamp kodi noto'g'ri.");
    const next = [...current.claimedStopIds, stop.id]; localStorage.setItem("samarkand-rally-demo-progress", JSON.stringify(next));
    return { progress: demoProgress() };
  }
  if (path === "/guide/chat") { const current = demoStops.find((stop) => stop.id === demoProgress().nextStopId); return { reply: current ? `${current.name}: ${current.story} Keyingi faol stamp shu nuqtada.` : "Siz barcha stampni to'pladingiz." }; }
  throw Error("Demo rejimida bu funksiya mavjud emas.");
}

function renderMiniPassport() {
  $("#stamp-count").textContent = progress.claimedCount;
  $("#hero-progress").textContent = `${String(Math.min(progress.claimedCount + 1, stops.length)).padStart(2, "0")} / ${String(stops.length).padStart(2, "0")}`;
  $("#mini-stamps").innerHTML = stops.map((stop, index) => `<div class="mini-stamp ${done(stop.id) ? "collected" : ""}">${done(stop.id) ? "&#10003;" : index + 1}</div>`).join("");
}

function renderRoute() {
  $("#route-list").innerHTML = stops.map((stop, index) => {
    const isDone = done(stop.id), locked = !isDone && progress.nextStopId !== stop.id;
    const copy = copyFor(stop);
    return `<article class="stop-card ${isDone ? "collected" : ""} ${locked ? "locked" : ""}"><div class="stop-number">${isDone ? "&#10003;" : String(index + 1).padStart(2, "0")}</div><div class="stop-main"><div class="stop-kicker">${isDone ? t("collected") : locked ? t("locked") : t("next")}</div><h3>${copy.name}</h3><p>${copy.hint}</p></div><button class="stop-action" data-stop="${index}" ${locked ? "disabled" : ""} aria-label="${copy.name}">${isDone ? "&#9733;" : "&#8594;"}</button></article>`;
  }).join("");
  all(".stop-action:not([disabled])").forEach((button) => button.addEventListener("click", () => openStamp(Number(button.dataset.stop))));
}

function renderMap() {
  const lines = stops.slice(1).map((stop, index) => { const a = stops[index].point, b = stop.point, dx = b[0] - a[0], dy = b[1] - a[1]; return `<div class="map-line" style="left:${a[0] + 19}px;top:${a[1] + 19}px;width:${Math.hypot(dx, dy)}px;transform:rotate(${Math.atan2(dy, dx) * 180 / Math.PI}deg)"></div>`; }).join("");
  $("#route-map").innerHTML = lines + stops.map((stop, index) => `<div class="map-pin ${done(stop.id) ? "done" : ""}" style="left:${stop.point[0]}px;top:${stop.point[1]}px">${done(stop.id) ? "&#10003;" : index + 1}</div>`).join("");
  const next = stops.find((stop) => stop.id === progress.nextStopId);
  const copy = next && copyFor(next);
  $("#next-stop").innerHTML = next ? `<p>${t("next")}</p><strong>${copy.name}</strong><p>${copy.hint}</p>` : `<p>${t("mapLabel")}</p><strong>${t("rewardUnlocked")}</strong>`;
}

function renderPassport() { $("#passport-stamps").innerHTML = stops.map((stop) => { const copy = copyFor(stop); return `<div class="passport-stamp ${done(stop.id) ? "collected" : ""}"><span class="mark">${done(stop.id) ? "SAM" : "?"}</span><strong>${done(stop.id) ? copy.name : t("lockedStamp")}</strong><small>${done(stop.id) ? "Samarkand Rally" : t("unlock")}</small></div>`; }).join(""); }
function renderReward() { const complete = progress.completed; $("#reward-page").innerHTML = `<p class="eyebrow">${complete ? "RALLY YAKUNI" : t("rewards")}</p><div class="medal"><span>SR</span><b>SAMARQAND</b><small>2026</small></div><h2>${t(complete ? "rewardUnlocked" : "rewardTitle")}</h2><p>${t(complete ? "rewardDone" : "rewardLocked")}</p><div class="reward-status"><span>${progress.claimedCount} / ${progress.totalStops}</span> ${t("stamps")}</div>`; }
function renderStrings() { all("[data-i18n]").forEach((node) => { node.textContent = t(node.dataset.i18n); }); all("[data-i18n-placeholder]").forEach((node) => { node.placeholder = t(node.dataset.i18nPlaceholder); }); all(".language").forEach((button) => button.classList.toggle("active", button.dataset.language === lang)); }
function render() { renderStrings(); renderMiniPassport(); renderRoute(); renderMap(); renderPassport(); renderReward(); }

function stopScanner() { if (scannerTimer) window.clearInterval(scannerTimer); scannerTimer = null; if (scannerStream) scannerStream.getTracks().forEach((track) => track.stop()); scannerStream = null; $("#scanner-shell").hidden = true; }
async function startScanner() {
  const status = $("#scanner-status");
  if (!navigator.mediaDevices?.getUserMedia) { status.textContent = "Bu brauzer kamerani qo'llamaydi. Kodni qo'lda kiriting."; return; }
  if (!("BarcodeDetector" in window)) { status.textContent = "Kamera ochildi, lekin QR o'qish qo'llanmaydi. Kodni qo'lda kiriting."; return; }
  try {
    stopScanner(); status.textContent = "QR kodni ramka ichiga tuting.";
    scannerStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
    const video = $("#qr-video"); video.srcObject = scannerStream; $("#scanner-shell").hidden = false; await video.play();
    const detector = new BarcodeDetector({ formats: ["qr_code"] });
    scannerTimer = window.setInterval(async () => { if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) return; try { const codes = await detector.detect(video); if (codes[0]?.rawValue) { $("#stamp-code").value = codes[0].rawValue.toUpperCase(); status.textContent = "Kod topildi. Stampni olish tugmasini bosing."; stopScanner(); } } catch { /* Keep scanning while a frame is unavailable. */ } }, 350);
  } catch { status.textContent = "Kameraga ruxsat berilmadi. Kodni qo'lda kiriting."; stopScanner(); }
}
function openStamp(index) { activeStop = index; const stop = stops[index], copy = copyFor(stop); $("#dialog-title").textContent = copy.name; $("#dialog-story").textContent = copy.story; $("#stamp-code").value = ""; $("#scanner-status").textContent = ""; $("#claim-error").textContent = ""; $("#collect-stamp").disabled = done(stop.id); $("#stamp-dialog").showModal(); }
function addGuide(kind, message) { const item = document.createElement("article"); item.className = `guide-message guide-message--${kind}`; item.textContent = message; $("#guide-feed").append(item); item.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
async function askGuide(message) { addGuide("visitor", message); $("#guide-input").value = ""; try { const current = stops.find((stop) => stop.id === progress.nextStopId); const data = await api("/guide/chat", { method: "POST", body: JSON.stringify({ message, stopId: current?.id, language: lang }) }); addGuide("assistant", data.reply); } catch (error) { addGuide("assistant", error.message); } }

$("#collect-stamp").addEventListener("click", async () => { const button = $("#collect-stamp"); button.disabled = true; $("#claim-error").textContent = ""; try { progress = (await api("/stamps/claim", { method: "POST", body: JSON.stringify({ stopId: stops[activeStop].id, stampCode: $("#stamp-code").value }) })).progress; render(); $("#stamp-dialog").close(); } catch (error) { $("#claim-error").textContent = error.message; button.disabled = false; } });
$(".dialog-close").addEventListener("click", () => $("#stamp-dialog").close());
$("#stamp-dialog").addEventListener("close", stopScanner);
$("#scan-qr").addEventListener("click", startScanner);
$(".start-rally").addEventListener("click", () => $("#route-list").scrollIntoView({ behavior: "smooth", block: "start" }));
$(".reset-progress").addEventListener("click", () => alert("Progress backendda saqlanadi; reset admin orqali qilinadi."));
all(".language").forEach((button) => button.addEventListener("click", () => { lang = button.dataset.language; localStorage.setItem("rally-lang", lang); render(); }));
all(".nav-item").forEach((button) => button.addEventListener("click", () => { all(".nav-item").forEach((item) => item.classList.remove("active")); all(".view").forEach((item) => item.classList.remove("active")); button.classList.add("active"); $("#" + button.dataset.view).classList.add("active"); window.scrollTo({ top: 0, behavior: "smooth" }); }));
$("#guide-form").addEventListener("submit", (event) => { event.preventDefault(); const message = $("#guide-input").value.trim(); if (message) askGuide(message); });
all(".guide-suggestion").forEach((button) => button.addEventListener("click", () => askGuide(button.textContent)));

(async () => { const data = await api("/rallies/samarkand-secrets"); stops = data.rally.stops; $("#stamp-total").textContent = stops.length; if (!token) { const session = await api("/sessions", { method: "POST", body: JSON.stringify({ language: lang }) }); token = session.session.token; localStorage.setItem("samarkand-rally-session", token); } progress = (await api("/me/progress")).progress; render(); })().catch((error) => { document.body.innerHTML = `<main class="app-shell"><section class="passport-page"><p class="eyebrow">SERVER ULANMADI</p><h2>Rallyni ishga tushirish kerak</h2><p>${error.message}</p><p>Terminalda <code>node backend/src/server.mjs</code> buyrug'ini ishlating.</p></section></main>`; });
