# Samarkand Rally

Interactive stamp-rally experience for visitors exploring Samarkand.

Live demo: https://samarkand-rally-uz.j5ndszhvzk.chatgpt.site

## Features

- Six-stop Samarkand rally with sequential stamps
- Uzbek, English, and Russian interface modes
- QR camera scanning with a manual code fallback
- Digital passport and reward flow
- Travel guide chat interface
- Installable PWA for iPhone, Android, and desktop
- Local Node.js backend and an admin overview endpoint

## Run locally

```bash
cd samarkand-rally
npm start
```

Open http://127.0.0.1:4173 in a browser.

## Test

```bash
npm test
```

## Demo QR codes

Use the rally order below:

1. `SAM-REG-2026`
2. `SAM-BIB-2026`
3. `SAM-SIY-2026`
4. `SAM-SHZ-2026`
5. `SAM-KON-2026`
6. `SAM-ULU-2026`

For Shohi Zinda, `SAM-SHO-2026` and `SAM-SHOHI-2026` also work.
